function allHighlight() {
    var x = document.getElementsByTagName("strong");
    var i;
    for (i = 0; i < x.length; i++) {
        x[i].style.color = "red";
        if (i === 6) { break; }
    }
}


function myFunction1() {
    document.getElementById("strong1").style.color = "#ff0000";
}

function myFunction2() {
    document.getElementById("strong2").style.color = "#ff0000";
}

function myFunction3() {
    document.getElementById("strong3").style.color = "#ff0000";
}

function myFunction4() {
    document.getElementById("strong4").style.color = "#ff0000";
}

function myFunction5() {
    document.getElementById("strong5").style.color = "#ff0000";
}

function myFunction6() {
    document.getElementById("strong6").style.color = "#ff0000";
}

function myFunction7() {
    document.getElementById("strong7").style.color = "#ff0000";
}

